import './App.css';
import LeftSideContact from './components/LeftSideContact/LeftSideContact';
import RightSideProfile from './components/RightSideProfile/RightSideProfile';
import ChatDiv from './components/ChatDiv/ChatDiv';

function App() {
  return (
    <div className="App">
    <RightSideProfile/>
    </div>
  );
}

export default App;
