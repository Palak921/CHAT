import React from 'react';
import ChatList from './ChatList';

class Requests extends React.Component {
    render() {
        return (
            <div>
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
                <ChatList name="Dinesh" />
            </div>
        )
    }
}

export default Requests;