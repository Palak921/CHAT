import React from 'react';
import ChatList from './ChatList';

class Chats extends React.Component{
    render(){
        return(
            <div>
                <ChatList name="Elizabeth Nelson" />
                <ChatList name="Elizabeth Nelson" />
                <ChatList name="Elizabeth Nelson" />
                <ChatList name="Elizabeth Nelson" />
                <ChatList name="Elizabeth Nelson" />
                <ChatList name="Elizabeth Nelson"/>
                <ChatList name="Elizabeth Nelson"/>
                <ChatList name="Elizabeth Nelson"/>
                
            </div>
            
        )
    }
}

export default Chats;